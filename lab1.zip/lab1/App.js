//BSCS3-2
//Cabasal, Jannie Iris
//Villeta, Via
//Perez de Tagle, Joshua P.

import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';

export default function App() {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
        Hello, World!
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'black',
  },
  paragraph: {
    margin: 24,
    fontSize: 26,
    fontWeight: 'bold',
    backgroundColor: 'gray',
    fontFamily: 'monospace',
    textAlign: 'center',
    color: 'white',
  },
});
