
 /* 
BSCS 3-2
Cabasal, Jannie Iris
Perez de Tagle, Joshua
Villeta, Via
*/

import React, {useState} from 'react';
import { View, Text, Button, StyleSheet, TextInput} from 'react-native';

export default function App() {
  const [textInputValue, setTextInputValue] = useState('');
  const [items, setItems] = useState([]);

  const goalInputHandler = (inputText) =>{
    setTextInputValue(inputText);
  };

  const addItemHandler = () => {
    setItems(currentItems => [...currentItems,'' + textInputValue]);
    setTextInputValue(" ");
  };

  return(
    <View style={styles.container}>
    <View style={styles.inputCon}> 
    <TextInput placeholder="Enter Item"
      style={styles.input} onChangeText ={goalInputHandler}
      value={textInputValue} />
      <Button title="Add" onPress={addItemHandler}/>
      </View>
      <View>
        { items.map((item) => (
          <View key={item} style ={styles.listItem}>
            <Text>{item}</Text>
           </View> 
        )) }
      </View> 
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 30,
    backgroundColor: "#dce5e9"
  },
  inputCon:{  
    flexDirection: "row",  
    justifyContent: "space-around",  
    alignItems: "center"  
  },  
  listItem: {
    backgroundColor: '#556580',
    padding: 10,  
    marginTop: 5 
  },
  input: {
    height: 40, 
    borderColor: '#5c5c5c', 
    borderWidth: 2,
    placeholderTextColor: 'gray',
    width: "80%"
  },  
});