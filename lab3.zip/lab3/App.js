//BSCS 3-2
//CABASAL, JANNIE IRIS
//PEREZ DE TAGLE, JOSHUA
// VILLETA, VIA


import React, {useState} from 'react';
import { View, Modal, Button, StyleSheet } from 'react-native';
import Constants from 'expo-constants';

import SampleModal from './components/SampleModal';
export default function App() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  return (
    <View style={styles.container}>

      <Button color = 'skyblue' title ="CLICK ME" onPress={() => setIsModalOpen(true)} />
        <SampleModal visible ={isModalOpen} onClose={() => setIsModalOpen(false)} />

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: 'beige',
    padding: 5,
    
  },
});


