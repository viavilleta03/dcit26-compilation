//BSCS 3-2
//CABASAL, JANNIE IRIS
//PEREZ DE TAGLE, JOSHUA
// VILLETA, VIA



import React from 'react';
import { Text, View, Button, Image, Modal, ScrollView, StyleSheet} from 'react-native';
import Constants from 'expo-constants';
const SampleModal = props => {
  return (
    <View styles={styles.cont} >
    <Modal visible={props.visible}>
    
    
    <ScrollView>
      <Image style={styles.picture} source={require('../assets/ocean.jpg')} />
      <Text style={styles.paragraph}>
      {'\n\n'} “ Doesn't matter how many times life drag you down never stop like the waves of the ocean." {'\n\n'}  


The origin of the oceans goes back to the time of the earth's formation 4. 6 billion years ago, when our planet was forming through the accumulation of smaller objects, called planetesimals. There are basically three possible sources for the water. It could have (1) separated out from the rocks that make up the bulk of the earth; (2) arrived as part of a late-accreting veneer of water- rich meteorites, similar to the carbonaceous chondrites that we see today; or (3) arrived as part of a late-accreting veneer of icy planetesimals, that is, comets.{'\n\n'}

The composition of the ocean offers some clues as to its origin. If all the comets contain the same kind of water ice that we have examined in Comets Halley and Hyakutake- -the only ones whose water molecules we've been able to study in detail-- then comets cannot have delivered all the water in the earth's oceans. We know this because the ice in the comets contains twice as many atoms of deuterium (a heavy isotope of hydrogen) to each atom of ordinary hydrogen as we find in seawater.{'\n\n'}

"At the same time, we know that the meteorites could not have delivered all of the water, because then the earth's atmosphere would contain nearly 10 times as much xenon (an inert gas) as it actually does. Meteorites all carry this excess xenon. Nobody has yet measured the concentration of xenon in comets, but recent laboratory experiments on the trapping of gases by ice forming at low temperatures suggest that comets do not contain high concentrations of the xenon. A mixture of meteoritic water and cometary water would not work either, because this combination would still contain a higher concentration of deuterium than is found in the oceans.{'\n\n'}

Hence, the best model for the source of the oceans at the moment is a combination of water derived from comets and water that was caught up in the rocky body of the earth as it formed. This mixture satisfies the xenon problem. It also appears to solve the deuterium problem--but only if the rocky material out near the earth's present orbit picked up some local water from the solar nebula (the cloud of gas and dust surrounding the young sun) before they accreted to form the earth. Some new laboratory studies of the manner in which deuterium gets exchanged between hydrogen gas and water vapor have indicated that the water vapor in the local region of the solar nebula would have had about the right (low) proportion of deuterium to balance the excess deuterium seen in comets.

The point to emphasize here is that this is a model, a working hypothesis that must be rigorously tested by many additional measurements. We need to study more comets. We also need to learn more about the water on Mars, where we have another chance to investigate the sources described above. On the earth, plate tectonics has caused oceanic water to mix considerably with material from the planet's interior; such contamination probably did not occur on Mars, where plate tectonics does not seem to occur. These investigations (and other related studies) are currently under way. This is an active area of research!"{'\n\n'}

James C. G. Walker of the University of Michigan confirms that conclusion, adding his perspective:{'\n\n'}

The best current thinking is that volatiles (elements and compounds, including water, that vaporize at low temperatures) were released from the solid phase as the earth accreted. Thus, the earth and its oceans and atmosphere grew together.
      </Text>
      </ScrollView>
       <Button color ='skyblue' title="Close" onPress ={props.onClose} />
    </Modal>
    </View>
  );
}
      
const styles = StyleSheet.create({
  cont: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: 'beige',
    padding: 8,
  },
  paragraph: {
    margin: 20,
    fontSize: 13,
    backgroundColor: 'beige',
    textAlign: 'justify',
    fontFamily: 'mcursive',
    color: 'black',
  },
  picture: {
    width: 500,
    height: 200,
   
  },
});


export default SampleModal;


