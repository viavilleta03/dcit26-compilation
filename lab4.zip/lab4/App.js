//BSCS 3-2
//CABASAL, JANNIE IRIS
//PEREZ DE TAGLE, JOSHUA
//VILLETA,VIA


import React from 'react';
import Navigation from './routes/MainStack';

export default function App() {
  return(
      <Navigation />
  );
}