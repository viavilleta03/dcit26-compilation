import React from 'react';
import {View,Button,StyleSheet, ImageBackground,Text, Modal} from 'react-native';


const image = { uri: "https://www.nawpic.com/media/2020/galaxy-background-nawpic-1.jpg" };


  
const Profile = ({navigation}) => {
    return(
        <View style={styles.image}>
<ImageBackground source={image} style={styles.image}>
      
    </ImageBackground>
            <Button color= "black" title="GO Back" onPress={() => navigation.goBack()} />
        </View>
    );
}

export default Profile;

const styles = StyleSheet.create({

    
    image:{
          flex: 1,
    resizeMode: "cover",
 
    }
});
