import React from 'react';
import {View, Button,StyleSheet, ImageBackground} from 'react-native';

const image = { uri: "https://archziner.com/wp-content/uploads/2020/02/cartoon-image-of-different-planets-on-black-galaxy-background-with-stars-turquoise-clouds.jpg" };


const Home = ({navigation}) => {
    return(
        <View style={styles.image}>
<ImageBackground source={image} style={styles.image}>
      
    </ImageBackground>
            <Button color= "black" title="PROFILE" onPress={() => navigation.navigate('Profile')} />
        </View>
    );
}

export default Home;

const styles = StyleSheet.create({

    
    image:{
          flex: 1,
    resizeMode: "cover",
  
    justifyContent: "center"
    }
});