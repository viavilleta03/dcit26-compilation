import React from 'react';
import {View,Button,StyleSheet, ImageBackground,Text, Modal} from 'react-native';


const image = { uri: "https://i.pinimg.com/originals/53/11/a4/5311a43f40813e2aaa917c829ed098f5.jpg" };


  
const Profile = ({navigation}) => {
    return(
        <View style={styles.image}>
<ImageBackground source={image} style={styles.image}>
  <Text  style={{color:'white', fontWeight: 'bold',
    fontFamily: 'monospace',textAlign: 'center',}}>
 
 <Text>
  Developer Information{'\n\n'}
  </Text>

<Text>
  Joshua Perez de Tagle{'\n'}
  Computer Science Student
  {'\n\n'}</Text>

<Text>
 Jannie Iris Cabasal{'\n'}
 Computer Science Student{'\n\n'}
</Text>

<Text>
  Via Villeta{'\n'}
  Computer Science Student
  {'\n\n'}
</Text>



  </Text>
  
    </ImageBackground>
   
            <Button color= "black" title="GO BACKHOME" onPress={() => navigation.goBack()} />
        </View>
    );
}

export default Profile;

const styles = StyleSheet.create({

    
    image:{
          flex: 1,
    resizeMode: "cover",
    justifyContent: "center"
    }
});