
//BSCS 3-2 
//CABASAL
//PEREZ DE TAGLE
//VILLETA



import React from 'react';
import Navigation from './routes/Drawer';

export default function App() {
  return(
      <Navigation />
  );
}