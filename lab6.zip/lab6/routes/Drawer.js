//BSCS 3-2 
//CABASAL
//PEREZ DE TAGLE
//VILLETA
import React from 'react';
import {NavigationContainer} from '@react-navigation/native'; 
import {createDrawerNavigator} from '@react-navigation/drawer';

import HomeStack from './HomeStack';


const Drawer = createDrawerNavigator();

const MainNavigator = () => {
  return (
    <NavigationContainer> 
      <Drawer.Navigator>
        <Drawer.Screen name = "Home"component = {HomeStack} />
       
      </Drawer.Navigator>
    </NavigationContainer>
  );
} 

export default MainNavigator;