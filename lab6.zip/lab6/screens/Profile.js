import React from "react";
import { View, StyleSheet, Text, ScrollView, Image } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { MaterialCommunityIcons } from '@expo/vector-icons';  
import {stylesst} from '../st/styles';

const Profile = ({ route, navigation }) => {
  const data = route.params;
 
  return (
    
    <View style={stylesst.container}>
      
    <ScrollView>
        <View style={stylesst.picFor}>
          <Image
            style={{width: 200, height: 200}}
            source={{ uri: data.picture.medium }}
          />
          <Text style={stylesst.text}>
            {data.name.first} {data.name.last}
          </Text>
        </View>

        <View style={stylesst.h2}>
          <MaterialCommunityIcons name="comment-account-outline" size={30} color="white" />
          <Text style={stylesst.textHeader}> About</Text>
        </View>

        <View>
          <Text style={stylesst.content}>
            Age: {data.dob.age} {'\n'}
            Birthday: {data.dob.date} {'\n'}
            Gender: {data.gender} {'\n'}
            Address: {data.location.street.number} {data.location.street.name}, {data.location.state}, {data.location.country}
          </Text>
        </View>

        <View style={stylesst.h2}>
          <MaterialCommunityIcons  name="phone" size={30} color="white" />
          <Text style={stylesst.textHeader}> Contact</Text>
        </View>
        
        <View>
          <Text style={stylesst.content}>
            Email: {data.email} {'\n'}
            Phone: {data.phone}
          </Text>
        </View>

        <View style={stylesst.h2}>
          <MaterialCommunityIcons name="drag-horizontal" size={30} color="white" />
          <Text style={stylesst.textHeader}> Other</Text>
        </View>

        <View>
          <Text style={stylesst.content}>
            Date Registered: {data.registered.date}
          </Text>
        </View>
      </ScrollView>
    </View>

  );
};

export default Profile;