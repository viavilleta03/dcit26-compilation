import { StyleSheet } from 'react-native';

export const stylesst = StyleSheet.create({
  container: {
    flex: 1,
    padding: '60',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'black',
    fontFamily: 'mcursive',
    color: 'white',
    fontWeight: 'bold',
  },
  picFor: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 10,
  },
  image: {
    width: '200',
    height: '250',
  },
  content: {
    fontSize: 15,
    fontFamily: 'mcursive',
    color: 'white',
    textAlign: 'justify',
  },
  text: {
    fontSize: 25,
    padding: 10,
    fontWeight: 'bold',
    justifyContent: 'center',
    alignContent: 'center',
    marginVertical: 10,
    backgroundColor: 'gray',
    fontFamily: 'mcursive',
    color: 'white',
    textAlign: 'justify',
    
  },
  textHeader: {
    fontSize: 20,
    fontFamily: 'mcursive',
    color: 'white',
    fontWeight: 'bold',
  },
  h2: {
    paddingTop: 30,
    flexDirection: 'row',
    fontFamily: 'mcursive',
    color: 'white',
    fontWeight: 'bold',
  },
});


